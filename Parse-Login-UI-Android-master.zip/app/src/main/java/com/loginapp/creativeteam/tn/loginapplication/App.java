package com.loginapp.creativeteam.tn.loginapplication;

import android.app.Application;

public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
